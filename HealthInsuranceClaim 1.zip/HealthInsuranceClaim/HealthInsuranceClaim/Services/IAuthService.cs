﻿using HealthInsuranceClaim.Models;
using HealthInsuranceClaim.DTOs;

namespace HealthInsuranceClaim.Services
{
    public interface IAuthService
    {
        Task<User?> LoginAsync(string username, string password);
        Task<string> RegisterAsync(RegisterRequest model);
    }
}