﻿using HealthInsuranceClaim.Models;

namespace HealthInsuranceClaim.DTOs
{
    public class PolicyDto
    {
        public string PolicyNumber { get; set; }
        public int PolicyholderId { get; set; }
        public decimal CoverageAmount { get; set; }
        public PolicyStatus PolicyStatus { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}