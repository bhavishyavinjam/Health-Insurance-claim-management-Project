﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Claims;

namespace HealthInsuranceClaim.Models
{
    public enum PolicyStatus
    {
        ACTIVE,
        INACTIVE,
        CANCELLED
    }

    public class Policy
    {
        [Key]
        public int PolicyId { get; set; }

        [Required, StringLength(50)]
        public string PolicyNumber { get; set; }

        [Required]
        public int PolicyholderId { get; set; }

        [ForeignKey("PolicyholderId")]
        public User Policyholder { get; set; }

        [Required, Column(TypeName = "decimal(10,2)")]
        public decimal CoverageAmount { get; set; }

        [Required]
        public PolicyStatus PolicyStatus { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; }

        public ICollection<Claim> Claims { get; set; }


    }


}
