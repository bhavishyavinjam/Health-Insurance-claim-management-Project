﻿using HealthInsuranceClaim.Models;
using System.Collections.Generic;
using System.Reflection.Emit;
using Microsoft.EntityFrameworkCore;



public class InsuranceContext : DbContext
{
    public InsuranceContext(DbContextOptions<InsuranceContext> options)
        : base(options)
    {
    }

    public DbSet<User> Users { get; set; }
    public DbSet<Policy> Policies { get; set; }
    public DbSet<Claim> Claims { get; set; }
    public DbSet<SupportTicket> SupportTickets { get; set; }
    public DbSet<Document> Documents { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Enum conversions
        modelBuilder.Entity<User>()
            .Property(u => u.Role)
            .HasConversion<string>();

        modelBuilder.Entity<Policy>()
            .Property(p => p.PolicyStatus)
            .HasConversion<string>();

        modelBuilder.Entity<Claim>()
            .Property(c => c.ClaimStatus)
            .HasConversion<string>();

        modelBuilder.Entity<SupportTicket>()
            .Property(t => t.TicketStatus)
            .HasConversion<string>();

        modelBuilder.Entity<Document>()
            .Property(d => d.DocumentType)
            .HasConversion<string>();

        // Relationships
        modelBuilder.Entity<Policy>()
            .HasOne(p => p.Policyholder)
            .WithMany(u => u.Policies)
            .HasForeignKey(p => p.PolicyholderId)
            .OnDelete(DeleteBehavior.Restrict);

        //modelBuilder.Entity<Claim>()
            //.HasOne(c => c.Policy)
            //.WithMany(p => p.Claims)
            //.HasForeignKey(c => c.PolicyId)
            //.OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Claim>()
            .HasOne(c => c.Adjuster)
            .WithMany(u => u.ClaimsAdjusted)
            .HasForeignKey(c => c.AdjusterId)
            .OnDelete(DeleteBehavior.SetNull);

        modelBuilder.Entity<SupportTicket>()
            .HasOne(t => t.User)
            .WithMany(u => u.SupportTickets)
            .HasForeignKey(t => t.UserId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Document>()
            .HasOne(d => d.Claim)
            .WithMany(c => c.Documents)
            .HasForeignKey(d => d.ClaimId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
