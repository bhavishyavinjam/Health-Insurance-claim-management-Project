﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HealthInsuranceClaim.Models
{
    public enum DocumentType
    {
        PDF,
        JPG,
        PNG,
        DOC
    }

    public class Document
    {
        [Key]
        public int DocumentId { get; set; }

        [Required]
        public int ClaimId { get; set; }

        [ForeignKey("ClaimId")]
        public Claim Claim { get; set; }

        [Required, StringLength(100)]
        public string DocumentName { get; set; }

        [Required, StringLength(255)]
        public string DocumentPath { get; set; }

        [Required]
        public DocumentType DocumentType { get; set; }
    }


}
