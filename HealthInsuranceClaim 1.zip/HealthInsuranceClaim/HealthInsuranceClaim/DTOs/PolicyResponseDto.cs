﻿using HealthInsuranceClaim.Models;

namespace HealthInsuranceClaim.DTOs
{
    public class PolicyResponseDto
    {
        public int PolicyId { get; set; }
        public string PolicyNumber { get; set; }
        public decimal CoverageAmount { get; set; }
        public string PolicyholderName { get; set; } // from User
        public PolicyStatus PolicyStatus { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
