﻿using System.ComponentModel.DataAnnotations;
using System.Security.Claims;

namespace HealthInsuranceClaim.Models
{
    public enum UserRole
    {
        ADMIN,
        AGENT,
        CLAIM_ADJUSTER,
        POLICYHOLDER
    }

    public class User
    {
        [Key]
        public int UserId { get; set; }

        [Required, StringLength(50)]
        public string Username { get; set; }

        [Required, StringLength(255)]
        public string Password { get; set; } // Should be encrypted

        [Required]
        public UserRole Role { get; set; }

        [Required, EmailAddress, StringLength(100)]
        public string Email { get; set; }

        public ICollection<Policy> Policies { get; set; }
        public ICollection<Claim> ClaimsAdjusted { get; set; }
        public ICollection<SupportTicket> SupportTickets { get; set; }
    }


}
