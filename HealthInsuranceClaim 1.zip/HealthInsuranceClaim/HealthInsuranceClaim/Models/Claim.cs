﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Reflection.Metadata;

namespace HealthInsuranceClaim.Models
{
    public enum ClaimStatus
    {
        PENDING,
        APPROVED,
        REJECTED
    }

    public class Claim
    {
        [Key]
        public int ClaimId { get; set; }

        [Required]
        public int PolicyId { get; set; }

        [ForeignKey("PolicyId")]
        public Policy Policy { get; set; }

        [Required, Column(TypeName = "decimal(10,2)")]
        public decimal ClaimAmount { get; set; }

        [Required]
        public DateTime ClaimDate { get; set; }

        [Required]
        public ClaimStatus ClaimStatus { get; set; }

        public int? AdjusterId { get; set; }

        [ForeignKey("AdjusterId")]
        public User Adjuster { get; set; }

        public ICollection<Document> Documents { get; set; }
    }


}
