﻿using HealthInsuranceClaim.Models;
using Microsoft.EntityFrameworkCore;
using HealthInsuranceClaim.DTOs;

namespace HealthInsuranceClaim.Services
{
    public class AuthService : IAuthService
    {
        private readonly InsuranceContext _context;

        public AuthService(InsuranceContext context)
        {
            _context = context;
        }

        public async Task<User?> LoginAsync(string username, string password)
        {
            return await _context.Users
                .FirstOrDefaultAsync(u => u.Username == username && u.Password == password);
        }

        public async Task<string> RegisterAsync(RegisterRequest model)
        {
            if (await _context.Users.AnyAsync(u => u.Username == model.Username))
                return "Username already exists";

            var user = new User
            {
                Username = model.Username,
                Password = model.Password, // ⚠️ Hash this in real projects
                Email = model.Email,
                Role = model.Role
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return "User registered successfully!";
        }
    }
}