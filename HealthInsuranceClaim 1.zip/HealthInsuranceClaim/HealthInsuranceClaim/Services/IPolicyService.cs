﻿using HealthInsuranceClaim.Models;
using HealthInsuranceClaim.DTOs;
 
public interface IPolicyService
{
    Task<IEnumerable<Policy>> GetAllAsync();
    Task<Policy> GetByIdAsync(int id);
    Task<Policy> CreateAsync(PolicyDto dto);
    Task UpdateAsync(int id, PolicyDto dto);
    Task DeleteAsync(int id);
}