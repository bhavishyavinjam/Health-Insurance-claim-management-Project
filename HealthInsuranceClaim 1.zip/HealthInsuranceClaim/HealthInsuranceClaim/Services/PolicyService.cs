﻿using HealthInsuranceClaim.DTOs;
using HealthInsuranceClaim.Models;
using Microsoft.EntityFrameworkCore;

namespace HealthInsuranceClaim.Services
{
    public class PolicyService : IPolicyService
    {
        private readonly InsuranceContext _context;

        public PolicyService(InsuranceContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Policy>> GetAllAsync()
        {
            return await _context.Policies.Include(p => p.Policyholder).ToListAsync();
        }

        public async Task<Policy> GetByIdAsync(int id)
        {
            return await _context.Policies.Include(p => p.Policyholder)
                .FirstOrDefaultAsync(p => p.PolicyId == id);
        }

        public async Task<Policy> CreateAsync(PolicyDto dto)
        {
            var policy = new Policy
            {
                PolicyNumber = dto.PolicyNumber,
                PolicyholderId = dto.PolicyholderId,
                CoverageAmount = dto.CoverageAmount,
                PolicyStatus = dto.PolicyStatus,
                CreatedDate = dto.CreatedDate
            };

            _context.Policies.Add(policy);
            await _context.SaveChangesAsync();
            return policy;
        }

        public async Task UpdateAsync(int id, PolicyDto dto)
        {
            var policy = await _context.Policies.FindAsync(id);
            if (policy == null) return;

            policy.PolicyNumber = dto.PolicyNumber;
            policy.PolicyholderId = dto.PolicyholderId;
            policy.CoverageAmount = dto.CoverageAmount;
            policy.PolicyStatus = dto.PolicyStatus;
            policy.CreatedDate = dto.CreatedDate;

            _context.Entry(policy).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var policy = await _context.Policies.FindAsync(id);
            if (policy != null)
            {
                _context.Policies.Remove(policy);
                await _context.SaveChangesAsync();
            }
        }
    }
}