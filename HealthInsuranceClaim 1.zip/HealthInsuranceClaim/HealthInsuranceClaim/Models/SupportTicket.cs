﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HealthInsuranceClaim.Models
{
    public enum TicketStatus
    {
        OPEN,
        RESOLVED
    }

    public class SupportTicket
    {
        [Key]
        public int TicketId { get; set; }

        [Required]
        public int UserId { get; set; }

        [ForeignKey("UserId")]
        public User User { get; set; }

        [Required]
        public string IssueDescription { get; set; }

        [Required]
        public TicketStatus TicketStatus { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; }
    }


}
